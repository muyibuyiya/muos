/* MUOS 本轮反馈回归：状态栏对比度 / 滚动保持 / 账户中心 / 快捷任务 / 导航三模式 /
   关闭提醒 / 桌面搜索框 / 桌面分页稳定性 / 计算器布局 / 应用商店 */
const fs = require('fs');
const { JSDOM, VirtualConsole } = require('jsdom');

const file = process.argv[2] || 'standalone.html';
const html = fs.readFileSync(file, 'utf8');
const errs = [];
const vc = new VirtualConsole();
vc.on('jsdomError', e => errs.push('jsdomError: ' + e.message));
vc.on('error', (...a) => errs.push('console.error: ' + a.join(' ')));

const dom = new JSDOM(html, {
  runScripts: 'dangerously', pretendToBeVisual: true,
  url: 'http://localhost/', virtualConsole: vc
});
const w = dom.window, d = w.document;
w.addEventListener('error', e => errs.push('window.error: ' + e.message));

let pass = 0, fail = 0;
function ck(name, cond, extra) {
  if (cond) { pass++; console.log('PASS ' + name); }
  else { fail++; console.log('FAIL ' + name + (extra ? ' | ' + extra : '')); }
}
function safe(name, fn) { try { fn(); } catch (e) { fail++; console.log('FAIL ' + name + ' threw: ' + e.message); } }
const wait = ms => new Promise(r => setTimeout(r, ms));

setTimeout(async () => {
  const NM = w.NM, S = NM.S;
  console.log('\n===== 反馈修复回归 =====');
  NM.beginUnlock();

  /* ---------- 1. 浅色背景下状态栏文字对比度 ---------- */
  safe('状态栏明暗自适应', () => {
    S.settings.theme = 'light'; S.settings.wall = 'nebula'; S.settings.cameraCutout = false;
    NM.applySettings();
    NM.setScreen('home');
    ck('浅色主题主屏用深色状态栏文字', d.documentElement.getAttribute('data-sb') === 'dark');
    NM.launchApp('settings');
    ck('浅色应用页用深色状态栏文字', d.documentElement.getAttribute('data-sb') === 'dark');
    NM.showShade('control');
    ck('控制中心展开时状态栏转白字', d.documentElement.getAttribute('data-sb') === 'light');
    NM.hideShade();
    NM.setScreen('lock');
    ck('锁屏暗底保持白色状态栏文字', d.documentElement.getAttribute('data-sb') === 'light');
    S.settings.cameraCutout = true; NM.updateStatusBarTone();
    ck('挖孔黑条强制白字', d.documentElement.getAttribute('data-sb') === 'light');
    S.settings.cameraCutout = false; S.settings.theme = 'dark'; NM.applySettings();
    NM.setScreen('home');
    ck('深色主题保持白字', d.documentElement.getAttribute('data-sb') === 'light');
  });

  /* ---------- 2. 页面滚动位置按栈帧保存 ---------- */
  safe('设置页滚动保持', () => {
    NM.beginUnlock(); NM.launchApp('settings');
    NM.setPage('settings', 'main');
    let body = d.querySelector('#view-settings .scroll');
    ck('设置页存在滚动容器', !!body);
    body.scrollTop = 180;
    NM.renderView(S.views.settings);
    body = d.querySelector('#view-settings .scroll');
    ck('同页重绘不跳回顶部', body.scrollTop === 180, String(body.scrollTop));
    NM.push('settings', 'display');
    body = d.querySelector('#view-settings .scroll');
    ck('进入新页从顶部开始', body.scrollTop === 0, String(body.scrollTop));
    NM.pop('settings');
    body = d.querySelector('#view-settings .scroll');
    ck('返回上级恢复原滚动位置', body.scrollTop === 180, String(body.scrollTop));
  });

  /* ---------- 3. 账户中心 ---------- */
  safe('账户卡片可点开', () => {
    NM.setPage('settings', 'main');
    const hero = d.querySelector('#view-settings .settings-hero[data-a]');
    ck('首页账户卡片可点击', !!hero && hero.getAttribute('data-v') === 'account');
    hero.click();
    const txt = d.getElementById('view-settings').textContent;
    ck('进入 MUOS 账户页', txt.indexOf('MUOS 账户') >= 0 || txt.indexOf('云同步') >= 0);
    ck('本机信息已移入账户页', txt.indexOf('屏幕与设备（只读）') >= 0);
    ck('账户页有云同步开关', !!d.querySelector('#view-settings [data-a="set-tg"][data-v="autoSync"]'));
    ck('账户页有同步项开关', !!d.querySelector('#view-settings [data-a="acct-sync"]'));
    ck('账户页有立即同步', !!d.querySelector('#view-settings [data-a="acct-sync-now"]'));
    ck('账户页有退出登录', !!d.querySelector('#view-settings [data-a="acct-logout"]'));
  });

  /* ---------- 4. 快捷任务区可折叠 / 可隐藏 ---------- */
  safe('快捷任务区', () => {
    NM.setPage('settings', 'main');
    ck('默认显示任务区', !!d.querySelector('#view-settings .task-grid'));
    const fold = d.querySelector('#view-settings [data-a="task-fold"]');
    ck('有折叠按钮', !!fold);
    fold.click();
    ck('折叠后只剩一行摘要', !!d.querySelector('#view-settings .task-fold-hint') &&
                            !d.querySelector('#view-settings .task-grid'));
    d.querySelector('#view-settings .task-fold-hint').click();
    ck('可再次展开', !!d.querySelector('#view-settings .task-grid'));
    S.settings.showTasks = false; NM.renderView(S.views.settings);
    ck('整块可隐藏', !d.querySelector('#view-settings .task-head'));
    S.settings.showTasks = true; NM.renderView(S.views.settings);
    NM.push('settings', 'taskShortcuts');
    const one = d.querySelector('#view-settings [data-a="task-toggle-one"]');
    ck('单项开关存在', !!one);
    one.click();
    ck('单项开关写入设置', !!(S.settings.taskHidden || {})[0]);
    NM.pop('settings');
  });

  /* ---------- 5. 导航栏三模式 ---------- */
  safe('导航三模式', () => {
    S.settings.nav = 'buttons'; NM.applySettings();
    ck('三键模式出现三个按钮', d.querySelectorAll('#navbar .nav-btn').length === 3);
    ck('三键模式 data-nav=buttons', d.documentElement.getAttribute('data-nav') === 'buttons');
    S.settings.nav = 'gesture'; NM.applySettings();
    ck('小横条模式清空三键栏', d.querySelectorAll('#navbar .nav-btn').length === 0);
    ck('小横条可见', d.getElementById('home-indicator').style.display !== 'none');
    S.settings.nav = 'none'; NM.applySettings();
    ck('不显示模式隐藏横条', d.getElementById('home-indicator').style.display === 'none');
    ck('不显示模式 data-nav=none', d.documentElement.getAttribute('data-nav') === 'none');
    S.settings.nav = 'gesture'; NM.applySettings();
  });

  /* ---------- 6. 关闭开关不弹顶部提醒且不挡状态栏 ---------- */
  safe('关闭提醒与状态栏遮挡', () => {
    const isl = d.getElementById('island');
    NM.island('WiFi 已开启', 1000);
    ck('开启类提示正常显示', !isl.classList.contains('quiet'));
    NM.island('WiFi 已关闭', 1000);
    ck('关闭类提示被抑制', isl.classList.contains('quiet'));
    ck('超级岛不接收指针事件', w.getComputedStyle(isl).pointerEvents === 'none');
  });

  /* ---------- 7. 桌面搜索框可关闭 ---------- */
  safe('桌面搜索框', () => {
    S.settings.showSearchPill = false; NM.applySettings();
    ck('关闭写入 data-searchpill=0', d.documentElement.getAttribute('data-searchpill') === '0');
    S.settings.showSearchPill = true; NM.applySettings();
    ck('开启写入 data-searchpill=1', d.documentElement.getAttribute('data-searchpill') === '1');
    ck('下滑搜索手势仍独立可配', S.settings.swipeSearch === true || S.settings.swipeSearch === false);
  });

  /* ---------- 8. 桌面分页稳定性 ---------- */
  safe('分页与小组件', () => {
    NM.goHome();
    const pages = d.querySelectorAll('#pages-track .app-page');
    ck('桌面有多页', pages.length >= 1);
    const trackH = d.documentElement.style.getPropertyValue('--track-h');
    ck('轨道高度按行高计算', parseFloat(trackH) > 0, trackH);
    ck('图标行高变量存在', d.documentElement.style.getPropertyValue('--icon-row-h') === '92px');
    ck('小组件只在第 0 页渲染', !!d.querySelector('#home-widget'));
    NM.gotoPage(0, true);
    ck('切页后页码条仍存在', !!d.querySelector('#page-dots .page-dot'));
    const dots = d.getElementById('page-dots');
    ck('页码条直接挂在 #home 下', dots.parentNode && dots.parentNode.id === 'home');
  });

  /* ---------- 9. 计算器布局 ---------- */
  safe('计算器布局', () => {
    NM.launchApp('calculator');
    const keys = d.querySelectorAll('#view-calculator .calc-key');
    ck('19 个按键全部渲染', keys.length === 19, String(keys.length));
    ck('操作符列完整', d.querySelectorAll('#view-calculator .calc-key.op').length === 5);
    ck('显示区有独立高度约束', html.indexOf('.calc-display') >= 0 &&
                                html.indexOf('grid-template-columns: repeat(4, minmax(0, 1fr))') >= 0);
  });

  /* ---------- 10. 应用商店 ---------- */
  safe('应用商店首页', () => {
    NM.launchApp('store');
    const v = d.getElementById('view-store');
    ck('商店有 5 个页签', v.querySelectorAll('.st-tabs button').length === 5);
    ck('商店有搜索框', !!v.querySelector('input[data-f="st-q"]'));
    ck('商店有推荐大卡', !!v.querySelector('.st-hero'));
    ck('商店有应用列表', v.querySelectorAll('.st-row').length >= 3);
    ck('商店不再是应用管理页', v.textContent.indexOf('后台上限 6 个') < 0);
    const open = v.querySelector('[data-a="st-open"]');
    open.click();
    const detail = d.getElementById('view-store').textContent;
    ck('可进入应用详情', detail.indexOf('应用介绍') >= 0 && detail.indexOf('用户评价') >= 0);
    ck('详情页有截图', !!d.querySelector('#view-store .st-shot'));
    ck('详情页有权限信息', detail.indexOf('所需权限') >= 0);
  });

  safe('商店搜索', () => {
    NM.setPage('store', 'main');
    const input = d.querySelector('#view-store input[data-f="st-q"]');
    input.value = '星野';
    input.dispatchEvent(new w.Event('input', { bubbles: true }));
    const res = d.querySelector('#st-results').textContent;
    ck('实时搜索命中应用', res.indexOf('星野') >= 0);
    ck('搜索时主区隐藏', d.querySelector('#st-main').style.display === 'none');
    input.value = '不存在的东西xyz';
    input.dispatchEvent(new w.Event('input', { bubbles: true }));
    ck('无结果有空态提示', d.querySelector('#st-results').textContent.indexOf('没有找到') >= 0);
  });

  /* 下载 -> 进度 -> 图标落到桌面 */
  NM.setPage('store', 'main');
  const target = (NM.STORE_CATALOG || [])[0];
  ck('商店目录已注册', !!target);
  const before = (S.data.desktop || []).indexOf(target.id);
  d.querySelector('#view-store [data-a="st-install"][data-v="' + target.id + '"]').click();
  await wait(2600);
  safe('下载安装流程', () => {
    ck('安装完成后写入安装列表', (S.data.storeInstalled || []).indexOf(target.id) >= 0);
    ck('图标添加到桌面', before < 0 && (S.data.desktop || []).indexOf(target.id) >= 0);
    ck('系统能解析商店应用', !!NM.appById(target.id));
    NM.goHome();
    ck('桌面渲染出商店应用图标', !!d.querySelector('#pages-track [data-app="' + target.id + '"]'));
    NM.launchApp(target.id);
    ck('商店应用可以点开', !!d.getElementById('view-' + target.id));
    NM.launchApp('store');
    NM.setPage('store', 'mine');
    ck('我的页列出已安装应用', d.getElementById('view-store').textContent.indexOf(target.n) >= 0);
  });

  /* ---------- 11. 长按桌面进入布局编辑器 ---------- */
  safe('长按桌面', () => {
    NM.goHome();
    const disp = d.getElementById('display');
    Object.defineProperty(disp, 'clientWidth', { get: () => 390, configurable: true });
    Object.defineProperty(disp, 'clientHeight', { get: () => 844, configurable: true });
    const home = d.getElementById('home');
    home.dispatchEvent(new w.MouseEvent('pointerdown', { bubbles: true, clientX: 180, clientY: 400 }));
  });
  await wait(680);
  safe('长按结果', () => {
    ck('长按 560ms 进入桌面布局', !!S.editing || d.getElementById('home-editor').classList.contains('on'));
    if (S.editing) NM.closeHomeEditor();
  });

  console.log('\n通过 ' + pass + '/' + (pass + fail));
  console.log('\n===== 运行时错误 (' + errs.length + ') =====');
  errs.slice(0, 12).forEach(e => console.log('  ' + e));
  process.exit(fail || errs.length ? 1 : 0);
}, 2600);
